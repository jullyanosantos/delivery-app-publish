import { Component, OnInit } from '@angular/core';
import { Pedido } from 'src/app/shared/models/pedidos/pedido';
import { PedidoService } from 'src/app/shared/services/pedido.service';

@Component({
  selector: 'app-acompanhar-pedido',
  templateUrl: './acompanhar-pedido.component.html',
  styleUrls: ['./acompanhar-pedido.component.css']
})
export class AcompanharPedidoComponent implements OnInit {

  pedidos: Pedido[];
  pedidosEmAndamento: Pedido[];
  draggedPedido: Pedido;

  constructor(private pedidoService: PedidoService) { }

  ngOnInit() {
    
    this.pedidos = this.pedidoService.getAllPedidos();
    this.pedidosEmAndamento = [];

    console.log(this.pedidos);
  }

  dragStart(event, pedido: Pedido) {
    this.draggedPedido = pedido;
  }

  allowDrop = (ev) => {
    ev.preventDefault();
    if (hasClass(ev.target,"drop-zone")) {
      addClass(ev.target,"droppable");
    }
  }

  dropp = (event) => {
    debugger
    event.preventDefault();
    const data = event.dataTransfer.getData("text/plain");
    const element = document.querySelector(`#${data}`);
    try {
      // remove the spacer content from dropzone
      event.target.removeChild(event.target.firstChild);
      // add the draggable content
      event.target.appendChild(element);
      // remove the dropzone parent
      unwrap(event.target);
    } catch (error) {
      console.warn("can't move the item to the same place")
    }

  }

  drop(event) {

    debugger
    if (this.draggedPedido) {
      let draggedPedidoIndex = this.findIndex(this.draggedPedido);
      this.pedidosEmAndamento = [...this.pedidosEmAndamento, this.draggedPedido];
      this.pedidos = this.pedidos.filter((val, i) => i != draggedPedidoIndex);
      this.draggedPedido = null;
    }
  }

  dragEnd(event) {
    this.draggedPedido = null;
  }

  findIndex(pedido: Pedido) {
    let index = -1;
    for (let i = 0; i < this.pedidos.length; i++) {
      if (pedido.id === this.pedidos[i].id) {
        index = i;
        break;
      }
    }
    return index;
  }
}

function hasClass(target, className) {
  return new RegExp('(\\s|^)' + className + '(\\s|$)').test(target.className);
}


function addClass(ele,cls) {
  if (!hasClass(ele,cls)) ele.className += " "+cls;
}

function removeClass(ele,cls) {
  if (hasClass(ele,cls)) {
    var reg = new RegExp('(\\s|^)'+cls+'(\\s|$)');
    ele.className=ele.className.replace(reg,' ');
  }
}

function unwrap(node) {
    node.replaceWith(...node.childNodes);
}